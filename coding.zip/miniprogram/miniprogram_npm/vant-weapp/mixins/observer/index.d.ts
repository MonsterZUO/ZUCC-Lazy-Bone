export declare function observe(vantOptions: any, options: any): void;
