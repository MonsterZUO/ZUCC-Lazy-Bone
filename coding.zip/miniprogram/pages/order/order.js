//page/order/order.js
var sliderWidth = 96; // 需要设置slider的宽度，用于计算中间位置
import Toast from '../../vant/toast/toast';
var util = require('../../util.js');
Page({
  data: {
    tabs: ["快递代拿", "快递代寄", "餐饮代买"],
    array: ['一食堂后面快递点', '宜博电竞馆快递点', 'cc网咖快递点', '北校南门快递点'],
    objectArray: [{
        id: 0,
        name: '一食堂后面快递点'
      },
      {
        id: 1,
        name: '宜博电竞馆快递点'
      },
      {
        id: 2,
        name: 'cc网咖快递点'
      },
      {
        id: 3,
        name: '北校南门快递点'
      }
    ],
    active: 0,
  },
  onLoad: function() {
    // 调用函数时，传入new Date()参数，返回值是日期和时间
    var time = util.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据
    this.setData({
      time: time
    })
  },
  //选择以后变更显示值
  bindPickerChange: function(e) {
    console.log(e.detail.value)
    console.log()
    this.setData({
      index: e.detail.value
    })
  },
  //姓名判定
  nameChange: function(event) {
    const name = event.detail.value;
    if (name) {
      if (/^[\u4e00-\u9fa5]{2,6}$/.test(name)) {} else {
        Toast('您输入的姓名有误')
      }
    } else {
      Toast('输入的姓名不能为空')
    }
    this.setData({
      _Name: name
    });
  },
  receiveNameChange: function(event) {
    const name = event.detail.value;
    if (name) {
      if (/^[\u4e00-\u9fa5]{2,6}$/.test(name)) {} else {
        Toast('您输入的姓名有误')
      }
    } else {
      Toast('输入的姓名不能为空')
    }
    this.setData({
      _receiveName: name
    });
  },
  buyNameChange: function(event) {
    const name = event.detail.value;
    if (name) {
      if (/^[\u4e00-\u9fa5]{2,6}$/.test(name)) {} else {
        Toast('您输入的姓名有误')
      }
    } else {
      Toast('输入的姓名不能为空')
    }
    this.setData({
      _buyName: name
    });
  },
  // 手机号判定
  phoneChange: function(event) {
    const phone = event.detail.value;
    if (phone) {
      if (/^1(3|4|5|7|8)\d{9}$/.test(phone)) {} else {
        Toast('您输入的手机号码有误')
      }
    } else {
      Toast('输入的手机号不能为空')
    }
    this.setData({
      _Phone: phone
    });
  },
  receivePhoneChange: function(event) {
    const phone = event.detail.value;
    if (phone) {
      if (/^1(3|4|5|7|8)\d{9}$/.test(phone)) {} else {
        Toast('您输入的手机号码有误')
      }
    } else {
      Toast('输入的手机号不能为空')
    }
    this.setData({
      _receivePhone: phone
    });
  },
  buyPhoneChange: function(event) {
    const phone = event.detail.value;
    if (phone) {
      if (/^1(3|4|5|7|8)\d{9}$/.test(phone)) {} else {
        Toast('您输入的手机号码有误')
      }
    } else {
      Toast('输入的手机号不能为空')
    }
    this.setData({
      _buyPhone: phone
    });
  },
  // 拿到取件码
  upKey: function(event) {
    this.setData({
      _Key: event.detail.value
    });
  },
  // 拿到备注
  upMessage: function(event) {
    console.log(event.detail.value)
    this.setData({
      _Message: event.detail.value
    });
  },
  // 拿到红包金额
  upBonus: function(event) {
    this.setData({
      _Bonus: event.detail.value
    });
  },
  //拿到地址
  upAddress: function(event) {
    this.setData({
      _Address: event.detail.value
    });
  },
  upReceiveAddress: function(event) {
    this.setData({
      _ReceiveAddress: event.detail.value
    });
  },
  upBuyAddress: function(event) {
    this.setData({
      _BuyAddress: event.detail.value
    });
  },
  //拿到身份证
  upIdcard: function(event) {
    this.setData({
      _Idcard: event.detail.value
    });
  },
  //确定按钮
  fetchInfo: function(event) {
    wx.cloud.init();
    const db = wx.cloud.database()
    const fetchOrder = db.collection('fetchOrder')

    fetchOrder.add({
      // data 字段表示需新增的 JSON 数据
      data: {
        fetchKey: this.data._Key,
        fetchName: this.data._Name,
        fetchPhone: this.data._Phone,
        fetchMessage: this.data._Message,
        fetchAddress: this.data.objectArray[this.data.index].name,
        fetchBonus: this.data._Bonus,
        isdone: false,
        isreceive: false,
        ordertime: db.serverDate(),
        type: '快递代拿',
        tag: '代拿',
        reputation: null,
        helperid: null,
        wantdone: false,
        wantcancel: false,
        iscancel: false,
      }
    }).then(res => {
      console.log(res.data)
      wx.switchTab({
        url: '../myOrder/myOrder',
      })
    })
  },
  sendInfo: function(event) {
    wx.cloud.init();
    const db = wx.cloud.database()
    const sendOrder = db.collection('sendOrder')

    sendOrder.add({
      // data 字段表示需新增的 JSON 数据
      data: {
        sendName: this.data._Name,
        sendPhone: this.data._Phone,
        sendAddress: this.data._Address,
        sendIdcard: this.data._Idcard,
        receiveName: this.data._receiveName,
        receivePhone: this.data._receivePhone,
        receiveAddress: this.data._ReceiveAddress,
        sendBonus: this.data._Bonus,
        sendMessage: this.data._Message,
        isdone: false,
        isreceive: false,
        ordertime: db.serverDate(),
        type: '快递代寄',
        tag: '代寄',
        reputation: null,
        helperid: null,
        wantdone: false,
        wantcancel: false,
        iscancel: false,
      }
    }).then(res => {
      console.log(res.data)
      wx.switchTab({
        url: '../myOrder/myOrder',
      })
    })
  },
  buyInfo: function(event) {

    wx.cloud.init();
    const db = wx.cloud.database()
    const buyOrder = db.collection('buyOrder')

    buyOrder.add({
      // data 字段表示需新增的 JSON 数据
      data: {
        buyerName: this.data._buyName,
        buyerPhone: this.data._buyPhone,
        buyMessage: this.data._Message,
        buyerAddress: this.data._BuyAddress,
        buyBonus: this.data._Bonus,
        isdone: false,
        isreceive: false,
        ordertime: db.serverDate(),
        type: '餐饮代买',
        tag: '代买',
        reputation: null,
        helperid: null,
        wantdone: false,
        wantcancel: false,
        iscancel: false,
      }
    }).then(res => {
      console.log(res.data)
      wx.switchTab({
        url: '../myOrder/myOrder',
      })
    })
  },
});