//reputation.js
const app = getApp()
const db = wx.cloud.database()
const fetchOrder = db.collection('fetchOrder')
const sendOrder = db.collection('sendOrder')
const buyOrder = db.collection('buyOrder')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    fetchOrder_list: [],
    sendOrder_list: [],
    buyOrder_list: [],
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        fetchOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'desc').where({
          _openid: res.result.openid,
          isdone:true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              fetchOrder_list: res.data
            })
          }
        })
        sendOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'desc').where({
          _openid: res.result.openid,
          isdone: true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              sendOrder_list: res.data
            })
          }
        })
        buyOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'desc').where({
          _openid: res.result.openid,
          isdone: true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              buyOrder_list: res.data
            })
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        fetchOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'asc').where({
          _openid: res.result.openid,
          isdone: true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              fetchOrder_list: res.data
            })
          }
        })
        sendOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'asc').where({
          _openid: res.result.openid,
          isdone: true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              sendOrder_list: res.data
            })
          }
        })
        buyOrder.orderBy('reputation', 'asc').orderBy('ordertime', 'asc').where({
          _openid: res.result.openid,
          isdone: true
        }).get({
          success: res => {
            console.log(res)
            this.setData({
              buyOrder_list: res.data
            })
          }
        })
      }
    })
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //评价星星
  upReputation(event) {
    this.setData({
      reputation: event.detail
    });
  },
  confirmReputation: function(event) {
    var id = event.currentTarget.dataset.id;
    db.collection('fetchOrder').doc(id).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        reputation: this.data.reputation
      },
      success(res) {
        console.log(res)
      }
    })
  },
  confirmSendReputation: function (event) {
    var id = event.currentTarget.dataset.id;
    db.collection('sendOrder').doc(id).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        reputation: this.data.reputation
      },
      success(res) {
        console.log(res)
      }
    })
  },
  confirmBuyReputation: function (event) {
    var id = event.currentTarget.dataset.id;
    db.collection('buyOrder').doc(id).update({
      // data 传入需要局部更新的数据
      data: {
        // 表示将 done 字段置为 true
        reputation: this.data.reputation
      },
      success(res) {
        console.log(res)
      }
    })
  },
})