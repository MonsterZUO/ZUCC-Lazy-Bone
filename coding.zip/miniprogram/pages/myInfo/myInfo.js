// pages/myInfo/myInfo.js
import Toast from '../../vant/toast/toast';
wx.cloud.init();
const db = wx.cloud.database()
const user = db.collection('user')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        var openid = res.result.openid
        user.where({
          _openid: res.result.openid
        }).count().then(res => {
          console.log(res.total)
          if (res.total != 0) {
            this.setData({
              isSign: true
            })
            user.where({
              _openid: openid
            }).get().then(res => {
              console.log(res.data)
              this.setData({
                userInfo:res.data
              })
            })
          } else {
            this.setData({
              isSign: false
            })
          }
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  nameChange: function(event) {
    const name = event.detail.value;
    if (name) {
      if (/^[\u4e00-\u9fa5]{2,6}$/.test(name)) {} else {
        Toast('您输入的姓名有误')
      }
    } else {
      Toast('输入的姓名不能为空')
    }
    this.setData({
      realName: name
    });
  },
  schoolNoChange: function(event) {
    this.setData({
      schoolNo: event.detail.value
    })
  },
  getUserInfo: function(result) {
    user.add({
      data: {
        userInfo: result.detail.userInfo,
        realName: this.data.realName,
        schoolNo: this.data.schoolNo
      }
    }).then(res => {
      console.log(res)
    }).catch(err => {
      console.error(err)
    })
  }
})