// pages/help/help.js
const db = wx.cloud.database()
const fetchOrder = db.collection('fetchOrder')
const sendOrder = db.collection('sendOrder')
const buyOrder = db.collection('buyOrder')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    active: 0,
    fetchOrder_list: [],
    sendOrder_list:[],
    buyOrder_list:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var _this = this;
    fetchOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          fetchOrder_list: res.data,
        })
      }
    })
    sendOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          sendOrder_list: res.data,
        })
      }
    })
    buyOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          buyOrder_list: res.data,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    fetchOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          fetchOrder_list: res.data,
        })
      }
    })
    sendOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          sendOrder_list: res.data,
        })
      }
    })
    buyOrder.orderBy('ordertime', 'desc').where({
      isreceive: false
    }).get({
      success: res => {
        console.log(res.data)
        this.setData({
          buyOrder_list: res.data,
        })
      }
    })
    wx.stopPullDownRefresh()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  receive: function(event) {
    var id = event.currentTarget.dataset.id;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        db.collection('fetchOrder').doc(id).update({
          data: {
            // 表示将 done 字段置为 true
            isreceive: true,
            helperid: res.result.openid
          },
          success(res) {
            console.log(res)
            wx.switchTab({
              url: '../myReceive/myReceive',
            })
          }
        })
      }
    })
  },
  receiveSend: function (event) {
    var id = event.currentTarget.dataset.id;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        db.collection('sendOrder').doc(id).update({
          data: {
            // 表示将 done 字段置为 true
            isreceive: true,
            helperid: res.result.openid
          },
          success(res) {
            console.log(res)
            wx.switchTab({
              url: '../myReceive/myReceive',
            })
          }
        })
      }
    })
  },
  receiveBuy: function (event) {
    var id = event.currentTarget.dataset.id;
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        db.collection('buyOrder').doc(id).update({
          data: {
            // 表示将 done 字段置为 true
            isreceive: true,
            helperid: res.result.openid
          },
          success(res) {
            console.log(res)
            wx.switchTab({
              url: '../myReceive/myReceive',
            })
          }
        })
      }
    })
  }
})